<?php $__env->startSection('content'); ?>
    <router-view></router-view>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    
    
    
    
    
    
    
    

    
    
    
    <script>

    </script>
    <script src="https://d.line-scdn.net/r/web/social-plugin/js/thirdparty/loader.min.js" async="async" defer="defer"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>