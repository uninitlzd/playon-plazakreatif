@extends('layouts.main')

@section('content')
    <router-view></router-view>
@stop

@section('scripts')
    {{--<script>--}}
    {{--$(function () {--}}
    {{--$.scrollify({--}}
    {{--section: ".playon-section",--}}
    {{--sectionName: "section-name",--}}
    {{--scrollbars: false,--}}
    {{--touchScroll: true,--}}
    {{--easing: "easeOutExpo",--}}
    {{--scrollSpeed: 2000,--}}

    {{--});--}}
    {{--});--}}
    {{--</script>--}}
    <script>

    </script>
    <script src="https://d.line-scdn.net/r/web/social-plugin/js/thirdparty/loader.min.js" async="async" defer="defer"></script>

@stop
