<template>
    <div>
        <div class="d-flex" style="height: 100vh; background: blue">aa</div>
        <div class="d-flex" style="height: 100vh; background: blue">aa</div>
    </div>
</template>
