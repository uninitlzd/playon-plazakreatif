<template>
    <a href="#tentang" style="width: 50px; height: 50px; background: #96c43e" class="d-flex justify-content-center" v-smooth-scroll>
        <i data-feather="arrow-right" class="text-white align-self-center"
           style="width: 20px; height: 20px"></i>
    </a>
</template>

<script>

</script>
